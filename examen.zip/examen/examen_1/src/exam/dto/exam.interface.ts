export interface ExamDto {
    description: string;
    isDone: boolean;
}