export class examDto {
    readonly description: string;
    readonly isDone: boolean;
}