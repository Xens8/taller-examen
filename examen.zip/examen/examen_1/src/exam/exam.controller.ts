import { Controller, Get, Render } from '@nestjs/common';
import { METHODS } from 'http';
import { Request } from '@nestjs/common';


@Controller('nosirve/v1')
export class ExamController { 
    @Get()
    @Render('index') 
    root() {
        return { message: 'hola ' };
    }
}