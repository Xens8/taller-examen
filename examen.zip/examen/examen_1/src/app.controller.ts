import { Get, Controller, Render } from '@nestjs/common';
import { AppService } from './app.service';

@Controller('/')
export class AppController {
  constructor(private appService: AppService) {}

  @Get('/')
  @Render('index') 
  hello() {
    return { message: '¡Hola a todos!' };
  }

  @Get('prueba/v1')
  @Render('prueba')
  root() {
    return { message: 'examen' };
  }


}